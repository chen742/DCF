# Obtained from: https://github.com/open-mmlab/mmsegmentation/tree/v0.16.0

from .misc import add_prefix

__all__ = ['add_prefix']
